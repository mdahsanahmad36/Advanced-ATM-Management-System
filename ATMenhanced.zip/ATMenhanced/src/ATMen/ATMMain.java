package ATMen;

import java.util.Scanner;

public class ATMMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank();

        System.out.println("===== Welcome to the ATM =====");

        int attempts = 3;
        User user = null;

        while (attempts > 0) {
            System.out.print("Enter Customer Number: ");
            int custNum = scanner.nextInt();
            System.out.print("Enter PIN: ");
            int pin = scanner.nextInt();

            user = bank.login(custNum, pin);
            if (user != null) break;

            attempts--;
            System.out.println("Incorrect credentials. Attempts left: " + attempts);
        }

        if (user == null) {
            System.out.println("Too many failed attempts. Exiting.");
            return;
        }

        while (true) {
            System.out.println("\nChoose Account Type:");
            System.out.println("1 - Checking Account");
            System.out.println("2 - Saving Account");
            System.out.println("3 - View Transaction History");
            System.out.println("4 - Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    accessAccount(scanner, user, "checking");
                    break;
                case 2:
                    accessAccount(scanner, user, "saving");
                    break;
                case 3:
                    System.out.println("Transaction History:");
                    for (String t : user.getTransactionHistory()) {
                        System.out.println(t);
                    }
                    break;
                case 4:
                    System.out.println("Thank you for using the ATM.");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void accessAccount(Scanner scanner, User user, String type) {
        while (true) {
            System.out.println("\n" + type.substring(0, 1).toUpperCase() + type.substring(1) + " Account:");
            System.out.println("1 - View Balance");
            System.out.println("2 - Deposit Funds");
            System.out.println("3 - Withdraw Funds");
            System.out.println("4 - Back");

            int option = scanner.nextInt();
            switch (option) {
                case 1:
                    double balance = type.equals("checking") ? user.getCheckingBalance() : user.getSavingBalance();
                    System.out.println("Current Balance: " + balance);
                    break;
                case 2:
                    System.out.print("Enter amount to deposit: ");
                    double dep = scanner.nextDouble();
                    user.deposit(type, dep);
                    System.out.println("Deposit successful.");
                    break;
                case 3:
                    System.out.print("Enter amount to withdraw: ");
                    double wd = scanner.nextDouble();
                    if (user.withdraw(type, wd)) {
                        System.out.println("Withdrawal successful.");
                    } else {
                        System.out.println("Insufficient funds.");
                    }
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
