package ATMen;

import java.util.HashMap;

public class Bank {
    private HashMap<Integer, User> users = new HashMap<>();

    public Bank() {
        // Predefined users
        users.put(12345, new User(12345, 789));
        users.put(11111, new User(11111, 123));
    }

    public User login(int customerNumber, int pin) {
        User user = users.get(customerNumber);
        if (user != null && user.validatePin(pin)) {
            return user;
        }
        return null;
    }
}
