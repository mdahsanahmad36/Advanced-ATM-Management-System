package ATMen;

import java.util.ArrayList;

public class User {
    private int customerNumber;
    private int pin;
    private double checkingBalance;
    private double savingBalance;
    private ArrayList<String> transactionHistory;

    public User(int customerNumber, int pin) {
        this.customerNumber = customerNumber;
        this.pin = pin;
        this.checkingBalance = 0;
        this.savingBalance = 0;
        this.transactionHistory = new ArrayList<>();
    }

    public boolean validatePin(int enteredPin) {
        return this.pin == enteredPin;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public double getCheckingBalance() {
        return checkingBalance;
    }

    public double getSavingBalance() {
        return savingBalance;
    }

    public void deposit(String accountType, double amount) {
        if (accountType.equalsIgnoreCase("checking")) {
            checkingBalance += amount;
        } else {
            savingBalance += amount;
        }
        transactionHistory.add("Deposited " + amount + " to " + accountType);
    }

    public boolean withdraw(String accountType, double amount) {
        if (accountType.equalsIgnoreCase("checking")) {
            if (checkingBalance >= amount) {
                checkingBalance -= amount;
                transactionHistory.add("Withdrew " + amount + " from " + accountType);
                return true;
            }
        } else {
            if (savingBalance >= amount) {
                savingBalance -= amount;
                transactionHistory.add("Withdrew " + amount + " from " + accountType);
                return true;
            }
        }
        return false;
    }

    public ArrayList<String> getTransactionHistory() {
        return transactionHistory;
    }
}
